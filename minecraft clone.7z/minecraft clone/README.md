# Minecraft Clone (C++)

First-person 3D voxel prototype in C++ using raylib.

## Requirements

- C++17 compiler
- CMake 3.24+
- Internet during first build (CMake downloads raylib source)

## Folder

`C:\Users\peter\minecraft clone`

## Build + Run (PowerShell)

```powershell
cd "C:\Users\peter\minecraft clone"
.\build.ps1
.\run.ps1
```

## Controls

- `W`: move forward
- `S`: move backward
- `A`: move left
- `D`: move right
- `Mouse`: look around
- `Left click`: destroy block
- `Right click`: place block
- `1-5`: select block type (grass, dirt, stone, wood, leaves)
- `Space`: jump
- `Esc`: close window

## Notes

- Block types included: grass, dirt, stone, wood, leaves.
- This is a generated sandbox world with mining/placing.
