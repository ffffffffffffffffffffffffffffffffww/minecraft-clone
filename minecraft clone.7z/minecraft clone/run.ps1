param(
    [string]$BuildDir = "build"
)

$ErrorActionPreference = "Stop"

$exe = Join-Path $BuildDir "Release\minecraft_clone.exe"
if (-not (Test-Path $exe)) {
    $exe = Join-Path $BuildDir "minecraft_clone.exe"
}

if (-not (Test-Path $exe)) {
    Write-Host "Executable not found. Building first..."
    & .\build.ps1 -BuildDir $BuildDir
    $exe = Join-Path $BuildDir "Release\minecraft_clone.exe"
    if (-not (Test-Path $exe)) {
        $exe = Join-Path $BuildDir "minecraft_clone.exe"
    }
}

& $exe
