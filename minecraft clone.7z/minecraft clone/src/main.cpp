#include "raylib.h"
#include "raymath.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <string>
#include <vector>

namespace {

constexpr int kWorldX = 48;
constexpr int kWorldY = 32;
constexpr int kWorldZ = 48;
constexpr float kReach = 6.5f;

enum BlockType : uint8_t {
    BLOCK_AIR = 0,
    BLOCK_GRASS = 1,
    BLOCK_DIRT = 2,
    BLOCK_STONE = 3,
    BLOCK_WOOD = 4,
    BLOCK_LEAVES = 5
};

struct HitResult {
    bool hit = false;
    int x = 0;
    int y = 0;
    int z = 0;
    int prevX = 0;
    int prevY = 0;
    int prevZ = 0;
};

std::vector<uint8_t> world(kWorldX * kWorldY * kWorldZ, BLOCK_AIR);

int Index(int x, int y, int z) {
    return x + y * kWorldX + z * kWorldX * kWorldY;
}

bool InBounds(int x, int y, int z) {
    return x >= 0 && y >= 0 && z >= 0 && x < kWorldX && y < kWorldY && z < kWorldZ;
}

BlockType GetBlock(int x, int y, int z) {
    if (!InBounds(x, y, z)) return BLOCK_STONE;
    return static_cast<BlockType>(world[Index(x, y, z)]);
}

void SetBlock(int x, int y, int z, BlockType type) {
    if (!InBounds(x, y, z)) return;
    world[Index(x, y, z)] = static_cast<uint8_t>(type);
}

bool IsSolid(BlockType type) {
    return type != BLOCK_AIR;
}

Color BlockColor(BlockType type) {
    switch (type) {
        case BLOCK_GRASS: return Color{67, 160, 71, 255};
        case BLOCK_DIRT: return Color{141, 90, 55, 255};
        case BLOCK_STONE: return Color{143, 148, 153, 255};
        case BLOCK_WOOD: return Color{139, 106, 63, 255};
        case BLOCK_LEAVES: return Color{47, 124, 52, 255};
        default: return BLANK;
    }
}

float HeightNoise(int x, int z) {
    const float a = std::sinf((x + 17) * 0.19f) * 2.2f;
    const float b = std::cosf((z - 5) * 0.15f) * 2.8f;
    const float c = std::sinf((x + z) * 0.07f) * 1.7f;
    return 9.0f + a + b + c;
}

void GrowTree(int x, int y, int z) {
    const int h = 3 + ((x * 13 + z * 11) & 1);
    for (int i = 0; i < h; ++i) SetBlock(x, y + i, z, BLOCK_WOOD);
    const int top = y + h;
    for (int dx = -2; dx <= 2; ++dx) {
        for (int dz = -2; dz <= 2; ++dz) {
            for (int dy = -2; dy <= 1; ++dy) {
                const int dist = std::abs(dx) + std::abs(dy) + std::abs(dz);
                if (dist <= 4 && GetBlock(x + dx, top + dy, z + dz) == BLOCK_AIR) {
                    SetBlock(x + dx, top + dy, z + dz, BLOCK_LEAVES);
                }
            }
        }
    }
}

void GenerateWorld() {
    for (int x = 0; x < kWorldX; ++x) {
        for (int z = 0; z < kWorldZ; ++z) {
            const int h = std::clamp(static_cast<int>(std::floor(HeightNoise(x, z))), 4, kWorldY - 6);
            for (int y = 0; y <= h; ++y) {
                if (y == h) SetBlock(x, y, z, BLOCK_GRASS);
                else if (y >= h - 2) SetBlock(x, y, z, BLOCK_DIRT);
                else SetBlock(x, y, z, BLOCK_STONE);
            }
            if (x > 2 && z > 2 && x < kWorldX - 3 && z < kWorldZ - 3) {
                const int r = (x * 73856093) ^ (z * 19349663);
                if ((r & 255) > 245) GrowTree(x, h + 1, z);
            }
        }
    }
}

bool PlayerIntersectsSolid(const Vector3& pos, float radius, float height) {
    const int minX = static_cast<int>(std::floor(pos.x - radius));
    const int maxX = static_cast<int>(std::floor(pos.x + radius));
    const int minY = static_cast<int>(std::floor(pos.y));
    const int maxY = static_cast<int>(std::floor(pos.y + height));
    const int minZ = static_cast<int>(std::floor(pos.z - radius));
    const int maxZ = static_cast<int>(std::floor(pos.z + radius));

    for (int x = minX; x <= maxX; ++x) {
        for (int y = minY; y <= maxY; ++y) {
            for (int z = minZ; z <= maxZ; ++z) {
                if (IsSolid(GetBlock(x, y, z))) return true;
            }
        }
    }
    return false;
}

Vector3 LookDirection(float yaw, float pitch) {
    return Vector3Normalize(Vector3{
        std::sinf(yaw) * std::cosf(pitch),
        std::sinf(pitch),
        std::cosf(yaw) * std::cosf(pitch)
    });
}

HitResult RaycastDDA(const Vector3& origin, const Vector3& dir, float maxDist) {
    HitResult out;
    int x = static_cast<int>(std::floor(origin.x));
    int y = static_cast<int>(std::floor(origin.y));
    int z = static_cast<int>(std::floor(origin.z));

    const int stepX = (dir.x > 0.0f) ? 1 : -1;
    const int stepY = (dir.y > 0.0f) ? 1 : -1;
    const int stepZ = (dir.z > 0.0f) ? 1 : -1;

    const float nextVoxelBoundaryX = x + ((stepX > 0) ? 1.0f : 0.0f);
    const float nextVoxelBoundaryY = y + ((stepY > 0) ? 1.0f : 0.0f);
    const float nextVoxelBoundaryZ = z + ((stepZ > 0) ? 1.0f : 0.0f);

    const float tMaxX = (std::fabs(dir.x) < 0.0001f) ? 1e30f : (nextVoxelBoundaryX - origin.x) / dir.x;
    const float tMaxY = (std::fabs(dir.y) < 0.0001f) ? 1e30f : (nextVoxelBoundaryY - origin.y) / dir.y;
    const float tMaxZ = (std::fabs(dir.z) < 0.0001f) ? 1e30f : (nextVoxelBoundaryZ - origin.z) / dir.z;

    const float tDeltaX = (std::fabs(dir.x) < 0.0001f) ? 1e30f : std::fabs(1.0f / dir.x);
    const float tDeltaY = (std::fabs(dir.y) < 0.0001f) ? 1e30f : std::fabs(1.0f / dir.y);
    const float tDeltaZ = (std::fabs(dir.z) < 0.0001f) ? 1e30f : std::fabs(1.0f / dir.z);

    float tx = tMaxX;
    float ty = tMaxY;
    float tz = tMaxZ;

    int prevX = x;
    int prevY = y;
    int prevZ = z;
    float traveled = 0.0f;

    while (traveled <= maxDist) {
        if (InBounds(x, y, z) && IsSolid(GetBlock(x, y, z))) {
            out.hit = true;
            out.x = x;
            out.y = y;
            out.z = z;
            out.prevX = prevX;
            out.prevY = prevY;
            out.prevZ = prevZ;
            return out;
        }

        prevX = x;
        prevY = y;
        prevZ = z;

        if (tx < ty && tx < tz) {
            x += stepX;
            traveled = tx;
            tx += tDeltaX;
        } else if (ty < tz) {
            y += stepY;
            traveled = ty;
            ty += tDeltaY;
        } else {
            z += stepZ;
            traveled = tz;
            tz += tDeltaZ;
        }
    }
    return out;
}

bool IsBlockExposed(int x, int y, int z) {
    return GetBlock(x + 1, y, z) == BLOCK_AIR ||
           GetBlock(x - 1, y, z) == BLOCK_AIR ||
           GetBlock(x, y + 1, z) == BLOCK_AIR ||
           GetBlock(x, y - 1, z) == BLOCK_AIR ||
           GetBlock(x, y, z + 1) == BLOCK_AIR ||
           GetBlock(x, y, z - 1) == BLOCK_AIR;
}

}  // namespace

int main() {
    InitWindow(1280, 720, "Minecraft Clone (C++ + raylib)");
    SetTargetFPS(144);
    DisableCursor();

    GenerateWorld();

    Vector3 playerPos{12.0f, 18.0f, 12.0f};
    const float playerRadius = 0.33f;
    const float playerHeight = 1.8f;
    Vector3 velocity{0.0f, 0.0f, 0.0f};
    float yaw = 0.0f;
    float pitch = 0.0f;
    bool onGround = false;
    BlockType selectedBlock = BLOCK_GRASS;

    Camera3D cam{};
    cam.position = playerPos;
    cam.up = Vector3{0.0f, 1.0f, 0.0f};
    cam.fovy = 75.0f;
    cam.projection = CAMERA_PERSPECTIVE;

    while (!WindowShouldClose()) {
        const float dt = GetFrameTime();

        const Vector2 mouseDelta = GetMouseDelta();
        const float sensitivity = 0.0022f;
        yaw -= mouseDelta.x * sensitivity;
        pitch -= mouseDelta.y * sensitivity;
        const float pitchLimit = PI / 2.0f - 0.01f;
        pitch = std::clamp(pitch, -pitchLimit, pitchLimit);

        Vector3 forward = Vector3Normalize(Vector3{std::sinf(yaw), 0.0f, std::cosf(yaw)});
        Vector3 right = Vector3Normalize(Vector3{forward.z, 0.0f, -forward.x});
        Vector3 wishDir{0.0f, 0.0f, 0.0f};

        if (IsKeyDown(KEY_W)) wishDir = Vector3Add(wishDir, forward);
        if (IsKeyDown(KEY_S)) wishDir = Vector3Subtract(wishDir, forward);
        if (IsKeyDown(KEY_A)) wishDir = Vector3Subtract(wishDir, right);
        if (IsKeyDown(KEY_D)) wishDir = Vector3Add(wishDir, right);

        if (Vector3Length(wishDir) > 0.0f) wishDir = Vector3Normalize(wishDir);

        const float moveSpeed = onGround ? 6.2f : 4.8f;
        velocity.x = wishDir.x * moveSpeed;
        velocity.z = wishDir.z * moveSpeed;

        velocity.y -= 24.0f * dt;
        if (onGround && IsKeyPressed(KEY_SPACE)) {
            velocity.y = 8.0f;
            onGround = false;
        }

        Vector3 tryPos = playerPos;
        tryPos.x += velocity.x * dt;
        if (!PlayerIntersectsSolid(tryPos, playerRadius, playerHeight)) {
            playerPos.x = tryPos.x;
        }

        tryPos = playerPos;
        tryPos.z += velocity.z * dt;
        if (!PlayerIntersectsSolid(tryPos, playerRadius, playerHeight)) {
            playerPos.z = tryPos.z;
        }

        onGround = false;
        tryPos = playerPos;
        tryPos.y += velocity.y * dt;
        if (!PlayerIntersectsSolid(tryPos, playerRadius, playerHeight)) {
            playerPos.y = tryPos.y;
        } else {
            if (velocity.y < 0.0f) onGround = true;
            velocity.y = 0.0f;
        }

        if (playerPos.y < 2.0f) {
            playerPos = Vector3{12.0f, 18.0f, 12.0f};
            velocity = Vector3{0.0f, 0.0f, 0.0f};
        }

        if (IsKeyPressed(KEY_ONE)) selectedBlock = BLOCK_GRASS;
        if (IsKeyPressed(KEY_TWO)) selectedBlock = BLOCK_DIRT;
        if (IsKeyPressed(KEY_THREE)) selectedBlock = BLOCK_STONE;
        if (IsKeyPressed(KEY_FOUR)) selectedBlock = BLOCK_WOOD;
        if (IsKeyPressed(KEY_FIVE)) selectedBlock = BLOCK_LEAVES;

        cam.position = Vector3Add(playerPos, Vector3{0.0f, playerHeight - 0.12f, 0.0f});
        const Vector3 lookDir = LookDirection(yaw, pitch);
        cam.target = Vector3Add(cam.position, lookDir);

        const HitResult hit = RaycastDDA(cam.position, lookDir, kReach);
        if (hit.hit && IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
            SetBlock(hit.x, hit.y, hit.z, BLOCK_AIR);
        }

        if (hit.hit && IsMouseButtonPressed(MOUSE_BUTTON_RIGHT)) {
            if (InBounds(hit.prevX, hit.prevY, hit.prevZ) && GetBlock(hit.prevX, hit.prevY, hit.prevZ) == BLOCK_AIR) {
                SetBlock(hit.prevX, hit.prevY, hit.prevZ, selectedBlock);
                if (PlayerIntersectsSolid(playerPos, playerRadius, playerHeight)) {
                    SetBlock(hit.prevX, hit.prevY, hit.prevZ, BLOCK_AIR);
                }
            }
        }

        BeginDrawing();
        ClearBackground(Color{135, 206, 235, 255});
        BeginMode3D(cam);

        for (int x = 0; x < kWorldX; ++x) {
            for (int y = 0; y < kWorldY; ++y) {
                for (int z = 0; z < kWorldZ; ++z) {
                    const BlockType type = GetBlock(x, y, z);
                    if (type == BLOCK_AIR) continue;
                    if (!IsBlockExposed(x, y, z)) continue;
                    const Vector3 p{static_cast<float>(x) + 0.5f, static_cast<float>(y) + 0.5f, static_cast<float>(z) + 0.5f};
                    DrawCube(p, 1.0f, 1.0f, 1.0f, BlockColor(type));
                    DrawCubeWires(p, 1.0f, 1.0f, 1.0f, Fade(BLACK, 0.15f));
                }
            }
        }

        if (hit.hit) {
            const Vector3 highlight{
                static_cast<float>(hit.x) + 0.5f,
                static_cast<float>(hit.y) + 0.5f,
                static_cast<float>(hit.z) + 0.5f
            };
            DrawCubeWires(highlight, 1.02f, 1.02f, 1.02f, YELLOW);
        }

        EndMode3D();

        DrawCircle(GetScreenWidth() / 2, GetScreenHeight() / 2, 3.0f, WHITE);
        DrawText("WASD move | Mouse look | Left click mine | Right click place | 1-5 block type", 16, 16, 20, WHITE);
        DrawRectangle(16, 44, 520, 30, Fade(BLACK, 0.35f));

        std::string selected = "Selected: ";
        switch (selectedBlock) {
            case BLOCK_GRASS: selected += "Grass"; break;
            case BLOCK_DIRT: selected += "Dirt"; break;
            case BLOCK_STONE: selected += "Stone"; break;
            case BLOCK_WOOD: selected += "Wood"; break;
            case BLOCK_LEAVES: selected += "Leaves"; break;
            default: selected += "Unknown"; break;
        }
        DrawText(selected.c_str(), 24, 50, 20, GOLD);

        EndDrawing();
    }

    CloseWindow();
    return 0;
}
