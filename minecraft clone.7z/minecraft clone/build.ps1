param(
    [string]$BuildDir = "build"
)

$ErrorActionPreference = "Stop"

if (-not (Get-Command cmake -ErrorAction SilentlyContinue)) {
    throw "cmake not found on PATH. Install CMake first."
}

cmake -S . -B $BuildDir
cmake --build $BuildDir --config Release

$exe = Join-Path $BuildDir "Release\minecraft_clone.exe"
if (-not (Test-Path $exe)) {
    $exe = Join-Path $BuildDir "minecraft_clone.exe"
}

if (Test-Path $exe) {
    Write-Host "Built: $exe"
} else {
    Write-Host "Build finished, but executable path may differ by generator."
}
